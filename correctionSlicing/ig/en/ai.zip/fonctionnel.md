# Fonctionnel - Volet de Synthèse Médicale (International Patient Summary - CDA) v0.1.0

## Fonctionnel

 
There is no translation page available for the current page, so it has been rendered in the default language 

* [Cas d'usage](./cas-usage.md)
* [Modèle logique métier](https://interop.esante.gouv.fr/ig/fhir/fr-patient-summary/StructureDefinition-fr-lm-patient-summary-document.html)
* [Exigences spécifiques](./exigences-specifiques.md)

