# ans.cda.fr.fr-patient-summary#0.1.0: Volet de Synthèse Médicale (International Patient Summary - CDA)(fr)

## Pages

* [Accueil](index.md)
* [Téléchargements et usages](annexe-downloads.md)
* [Informations sur la traduction](translationinfo.md)
* [Résumé des artefacts](artifacts.md)
* [Fonctionnel](fonctionnel.md)
* [Cas d'usage](cas-usage.md)
* [Autres Ressources](autres_ressources.md)
* [Exigences spécifiques](exigences-specifiques.md)
* [Sécurité](securite.md)
* [Implémentations](implementations.md)
* [CDA](cda.md)

## Resources

### Logical Profiles

* [CDA - clinicalDocument IPS](StructureDefinition-fr-cda-clinical-document-ips.md)

### Binaries

* [patient-summary](Binary-patient-summary.md)

### ImplementationGuides

* [Volet de Synthèse Médicale (International Patient Summary - CDA)](ImplementationGuide-ans.cda.fr.fr-patient-summary.md)
