# ModifiedAdministrativeGender - FR Patient Summary (CDA) v0.1.0

## ValueSet: ModifiedAdministrativeGender 

 
AdministrativeGender without unknown code 

 **References** 

* [Patient français](StructureDefinition-fr-patient.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ModifiedAdministrativeGender",
  "url" : "https://interop.esante.gouv.fr/ig/cda/fr-patient-summary/ValueSet/ModifiedAdministrativeGender",
  "version" : "0.1.0",
  "name" : "ModifiedAdministrativeGender",
  "title" : "ModifiedAdministrativeGender",
  "status" : "draft",
  "date" : "2026-09-28T08:51:21+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "AdministrativeGender without unknown code",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/administrative-gender",
      "version" : "5.0.0"
    }],
    "exclude" : [{
      "system" : "http://hl7.org/fhir/administrative-gender",
      "version" : "5.0.0",
      "concept" : [{
        "code" : "unknown"
      }]
    }]
  }
}

```
